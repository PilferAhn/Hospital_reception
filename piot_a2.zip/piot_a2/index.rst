.. MAPS documentation master file, created by
   sphinx-quickstart on Sun Sep  9 09:36:43 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MAPS's documentation!
================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   about
   code



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
