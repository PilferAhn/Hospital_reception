# piot_a2
Semester 2, 2018 RMIT Programming IoT Assignment 2

Assignment Description
- To be added

Developers
- s3558745 Minyoung Cho
- s3604496 Alex Ryland
- s3560873 Jimin Ahn
- s3615893 Wee Jueh Ang

Language
- Python

Devices to be used
- Raspberry Pi
- To be added
